#!/bin/bash
#SBATCH --job-name=hpcg
#SBATCH --output=run.out
#SBATCH --error=run.err
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=8
#SBATCH --gpus=2
#SBATCH --time=00:10:00
#SBATCH --partition=V100
#SBATCH --export=OMP_NUM_THREADS=4

export CXX_PATH=/usr
export PATH=${CXX_PATH}/bin:${PATH}
export CUDA_PATH=/usr/local/cuda
export NCCL_PATH=/home/hpc101/h3240104875/spack/opt/spack/linux-icelake/nccl-2.27.5-1-z3lvfjgs3t6mcj7ofzjoj3i355ylwbqt
export MPI_PATH=/home/hpc101/h3240104875/spack/opt/spack/linux-icelake/openmpi-5.0.8-asyldt75f5aji34ysxc5k6xakkghgyye
export MATHLIBS_PATH=${CUDA_PATH}/lib64

#Please fix, if needed
source ~/spack/share/spack/setup-env.sh
spack load cuda
spack load openmpi
spack load nccl
export CUDA_BLAS_VERSION=${CUDA_BUILD_VERSION:-12.2}
export LD_LIBRARY_PATH=${MATHLIBS_PATH}/${CUDA_BLAS_VERSION}/lib64/:${LD_LIBRARY_PATH}
export PATH=${CUDA_PATH}/bin:${PATH}
export LD_LIBRARY_PATH=${CUDA_PATH}/lib64:${LD_LIBRARY_PATH}
export LD_LIBRARY_PATH=${NCCL_PATH}/lib:${LD_LIBRARY_PATH}
export LD_LIBRARY_PATH=${NVPL_SPARSE}/lib:${LD_LIBRARY_PATH}
export LD_LIBRARY_PATH=${MPI_PATH}/lib:${LD_LIBRARY_PATH}
# export CUDA_VISIBLE_DEVICES=0

ext="--gpu-bind none"

#Directory to xhpcg binary
dir="bin"

#Sample on a Hopper GPU x86
###########################
#Local problem size
nx=203 #Large problem size x
ny=203 #Large problem size y
nz=203 #Large problem size z
srun  ${ext} ${dir}/hpcg.sh  --exec-name ${dir}/xhpcg \
 --nx $nx --ny $ny --nz $nz --rt 10 --b 0